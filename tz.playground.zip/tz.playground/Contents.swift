// MARK: - класс существо

import Foundation

class Creature {
    // MARK: - параметры
    
    var name: String
    var attack: Int
    var defense: Int
    var health: Int
    var damage: (min: Int, max: Int)
    
    // MARK: - инициализация
    
    init(name: String, attack: Int, defense: Int, health: Int, damage: (min: Int, max: Int)) {
        self.name = name
        self.attack = attack
        self.defense = defense
        self.health = health
        self.damage = damage
    }
    
    // MARK: - функции
    
    // рассчёт модификатора
    func attackModifier() -> Int {
        return self.attack - self.defense + 1
    }
    
    // проверка на удар
    func isStrikeSuccessful() -> Bool {
        let attackModifier = self.attackModifier()
        for _ in 1...attackModifier {
            let randomNumber = Int.random(in: 1...6)
            if randomNumber == 5 || randomNumber == 6 {
                return true
            }
        }
        return false
    }
    
    // считать урон
    func calculateDamage() -> Int {
        return Int.random(in: self.damage.min...self.damage.max)
    }
    
    // атака другого существа
    func attack(target: Creature) {
        if self.isStrikeSuccessful() {
            let damage = self.calculateDamage()
            target.health -= damage
            print("\(self.name) hits \(target.name) for \(damage) damage!")
        } else {
            print("\(self.name) misses \(target.name)!")
        }
    }
    
    // хилка
    func heal() {
        self.health += self.health / 2
        print("\(self.name) heals for \(self.health / 2)!")
    }
}

// MARK: - Класс игрок

class Player: Creature {
    // MARK: - Свойства
    
    var numberOfHeals: Int
    
    // MARK: - Инициализация
    
    init(name: String, attack: Int, defense: Int, health: Int, damage: (min: Int, max: Int), numberOfHeals: Int) {
        self.numberOfHeals = numberOfHeals
        super.init(name: name, attack: attack, defense: defense, health: health, damage: damage)
    }
    
    // MARK: - Методы
    
    override func heal() {
        if self.numberOfHeals > 0 {
            super.heal()
            self.numberOfHeals -= 1
        }
    }
}

// MARK: - Класс монстр

class Monster: Creature {
    // MARK: - Инициализация
    
    override init(name: String, attack: Int, defense: Int, health: Int, damage: (min: Int, max: Int))
    {
        super.init(name: name, attack: attack, defense: defense, health: health, damage: damage)
    }
}

// MARK: - Пример

let player = Player(name: "Player", attack: 15, defense: 10, health: 100, damage: (min: 1, max: 8), numberOfHeals: 3)
let monster = Monster(name: "Monster", attack: 12, defense: 8, health: 80, damage: (min: 2, max: 10))

player.attack(target: monster)
player.heal()
player.attack(target: monster)
monster.attack(target: player)
